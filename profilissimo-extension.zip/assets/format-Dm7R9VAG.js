function a(e){const n=e.name.split(" ")[0];return e.email?`${n} (${e.email})`:e.name}function r(e){return e instanceof Error?e.message:"Unknown error"}export{r as e,a as p};
